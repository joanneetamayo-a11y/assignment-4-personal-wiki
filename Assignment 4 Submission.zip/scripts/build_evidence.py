#!/usr/bin/env python3
"""Format real evaluation records into reviewable cards; never generate answers."""
import argparse
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('evaluation', help='Path to an existing evaluation directory')
args = parser.parse_args()
evaluation = (ROOT / args.evaluation).resolve()
results = json.loads((evaluation / 'results.json').read_text())
out = evaluation / 'cards'
out.mkdir(exist_ok=True)

def link(path):
    return os.path.relpath(path, out).replace(' ', '%20')

assessments = {
    'ask-1': 'Review the variable, configuration alternative, restart instruction, and log message against the cited FAQ passage.',
    'ask-2': 'Check the stated memory relationship and parallel-request claim separately. The source establishes that more context uses more memory; it does not supply a byte formula or detailed mechanism.',
    'ask-3': 'Check vector representation, storage, and cosine similarity against the embeddings introduction. This source supports the retrieval component, not a complete account of answer generation.',
    'ask-4': 'The originals contain no timing measurement for this specific computer. The required behavior is insufficient evidence.',
}
rows = []
for item in results:
    if item['label'] not in assessments:
        continue
    path = next((ROOT / p for p in item['records'] if p.endswith('-ask.json')), None)
    if path is None:
        raise SystemExit('Missing actual answer record: ' + item['label'])
    record = json.loads(path.read_text())
    expectation = item['expectation']
    text = f'# {item["label"]} evidence card\n\n'
    text += f'Question: {record["question"]}\n\nExpected behavior: {expectation["expected_behavior"]}\n\n'
    text += f'Expected source: {expectation["expected_source"] or "None; unsupported question"}\n\n'
    text += f'Expected evidence: {expectation["expected_evidence"] or "No supporting passage in the originals"}\n\n'
    text += f'Execution: local. Timestamp: {record["timestamp"]}.\n\n'
    text += 'Model identity and measurement:\n\n```json\n' + json.dumps(
        {k:record.get(k) for k in ['identity','metrics','options','thinking']},indent=2) + '\n```\n\n'
    text += '## Actual displayed answer\n\n' + record['answer'] + '\n\n'
    if record.get('raw_model_answer') != record['answer']:
        text += '## Original model output before harness checks\n\n' + str(record.get('raw_model_answer')) + '\n\n'
    text += '## Retrieved original passages\n\n'
    for hit in record['retrieved']:
        text += f'### [{hit["label"]}] {hit["path"]}, lines {hit["start"]}–{hit["end"]}\n\n'
        text += f'[Open original]({link(ROOT/hit["path"])}). Retrieval score: {hit["score"]}.\n\n'
        text += '\n'.join('> '+line for line in hit['passage'].splitlines()) + '\n\n'
    text += '## Citation check and review\n\n```json\n' + json.dumps(record['citation_check'],indent=2) + '\n```\n\n'
    text += assessments[item['label']] + '\n\nThe assessment of actual claims is recorded in the evaluation review; valid labels alone do not prove support.\n\n'
    text += f'[Unmodified JSON record]({link(path)})\n'
    (out / (item['label'] + '.md')).write_text(text)
    rows.append(f'- [{item["label"]}]({item["label"]}.md): {record["question"]}')

(out/'index.md').write_text('# Research evidence cards\n\n'+'\n'.join(rows)+'\n\n'
    'These cards reproduce actual saved outputs. See the run network manifest for offline verification and the separate review for answer quality.\n')
print(out)
