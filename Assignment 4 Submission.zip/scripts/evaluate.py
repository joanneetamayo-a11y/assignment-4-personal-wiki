#!/usr/bin/env python3
"""Run actual local-model checks; preserve every transcript and output path."""
import datetime, hashlib, json, pathlib, subprocess, sys, time
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import wiki
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
out=ROOT/'evidence'/'evaluations'/stamp;out.mkdir(parents=True)
results=[]
def run(label,args,input=None):
    before=set((ROOT/'evidence'/'runs').glob('*.json'))
    start=time.perf_counter()
    proc=subprocess.run([sys.executable,str(ROOT/'wiki.py'),*args],cwd=ROOT,input=input,text=True,capture_output=True,timeout=300)
    transcript='$ python3 wiki.py '+' '.join(args)+'\n'+(input or '')+proc.stdout+proc.stderr
    (out/(label+'.txt')).write_text(transcript)
    print(transcript,flush=True)
    files=sorted(set((ROOT/'evidence'/'runs').glob('*.json'))-before)
    result={'label':label,'exit_code':proc.returncode,'elapsed_seconds':round(time.perf_counter()-start,3),
            'records':[str(p.relative_to(ROOT)) for p in files]}
    results.append(result)
    return result,files
run('help',['help'])
# Regeneration is explicit; the harness backs up the previously reviewed note.
run('ingest',['ingest','vault/raw/Ollama Embeddings.md','--regenerate'])
for case in json.loads((ROOT/'tests/questions.json').read_text()):
    result,files=run(case['id'],['ask',case['question']])
    record=next((json.loads(p.read_text()) for p in files if p.name.endswith('-ask.json')),None)
    result['expectation']=case
    if record:
        result['expected_source_retrieved']= any(h['path']==case['expected_source'] and (case['expected_evidence'] or '') in h['passage'] for h in record['retrieved']) if case['expected_source'] else None
        result['assessment']='Pending semantic review of actual output.'
run('chat',['chat'], 'what can we do?\nwhat can you help me with?\nDraft a friendly two-sentence invitation to a study session.\nmake that shorter\nFor this conversation, my fictional project code is Lantern Mango.\n/exit\n')
run('chat-isolation',['ask','What is my project code?'])
run('search',['search','embeddings cosine similarity'])
# Content checks catch accidental overwrites and duplicate note creation.
before={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'vault').rglob('*.md')}
run('reingest',['ingest','vault/raw'])
after={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'vault').rglob('*.md')}
results.append({'label':'reingestion_preserves_files','passed':before==after})
run('audit',['audit'])
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
print('Evaluation directory: '+str(out),flush=True)
if any(r.get('exit_code',0)!=0 or r.get('passed') is False for r in results):sys.exit(1)
