#!/usr/bin/env python3
"""Mac-only physical offline demonstration with a real PTY recording and Wi-Fi restoration."""
import datetime, errno, json, os, pathlib, pty, select, shutil, signal, stat, subprocess, sys, threading, time

ROOT = pathlib.Path(__file__).resolve().parents[1]
STAMP = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
OUT = ROOT / 'evidence/offline-runs' / STAMP
OUT.mkdir(parents=True)
NET = '/usr/sbin/networksetup'
DEVICE = 'en0'
log = (OUT / 'network.txt').open('w', buffering=1)

def command(args):
    result = subprocess.run(args, text=True, capture_output=True, timeout=15)
    log.write('$ ' + ' '.join(args) + '\n' + result.stdout + result.stderr
              + 'exit_code=' + str(result.returncode) + '\n')
    return result

def record(args, timeout, name):
    """Record actual terminal output and timing as asciicast v2; never fabricate screens."""
    master, slave = pty.openpty()
    process = subprocess.Popen(args, cwd=ROOT, stdin=subprocess.DEVNULL,
                               stdout=slave, stderr=slave, start_new_session=True)
    os.close(slave)
    start = time.monotonic()
    try:
        with (OUT / (name + '.txt')).open('wb') as plain, (OUT / (name + '.cast')).open('w') as cast:
            cast.write(json.dumps({'version':2, 'width':120, 'height':40,
                                   'timestamp':int(time.time()), 'title':'Local wiki evaluation'}) + '\n')
            while True:
                if time.monotonic() - start > timeout:
                    raise TimeoutError('Recorded evaluation exceeded its time limit.')
                ready, _, _ = select.select([master], [], [], 0.5)
                if ready:
                    try:
                        chunk = os.read(master, 65536)
                    except OSError as exc:
                        if exc.errno == errno.EIO: break
                        raise
                    if not chunk: break
                    plain.write(chunk); plain.flush()
                    cast.write(json.dumps([round(time.monotonic()-start,3), 'o',
                                           chunk.decode('utf-8',errors='replace')]) + '\n')
                    cast.flush()
                elif process.poll() is not None:
                    break
        return process.wait(timeout=10)
    finally:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            try: process.wait(timeout=5)
            except subprocess.TimeoutExpired: os.killpg(process.pid, signal.SIGKILL)
        os.close(master)

initial = command([NET, '-getairportpower', DEVICE])
if 'On' not in initial.stdout:
    raise SystemExit('Expected Wi-Fi initially on; no setting changed.')
# iCloud placeholders have paths and sizes but cannot be read offline.
required_files = [ROOT/'wiki.py', ROOT/'sources.json', ROOT/'.local/ingestion.json']
for folder in ['instructions', 'tests', 'scripts', 'vault', '.local/models', '.local/runtime']:
    required_files.extend(p for p in (ROOT/folder).rglob('*') if p.is_file())
placeholders = [str(p.relative_to(ROOT)) for p in required_files if p.exists()
                and p.stat().st_flags & stat.SF_DATALESS]
(OUT/'file-availability.json').write_text(json.dumps({'cloud_placeholders':placeholders},indent=2)+'\n')
if placeholders:
    raise SystemExit('Files are still cloud placeholders. In Finder choose Keep Downloaded for the project, '
                     'wait for download completion, then retry. Wi-Fi was not changed.\n'+'\n'.join(placeholders))
# Exercise exactly the same process and recorder path before touching the network.
code = record([sys.executable, str(ROOT/'wiki.py'), 'model-info'], 30, 'preflight')
if code or 'gemma4:e2b' not in (OUT/'preflight.txt').read_text():
    raise SystemExit('Local model or recorder unavailable. Wi-Fi was not changed.')

before = set((ROOT/'evidence/evaluations').glob('*'))
samples = []
network_samples = []
stop = threading.Event()
status = {'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'verified':False, 'attempt_directory':str(OUT.relative_to(ROOT))}

def sample_memory():
    while not stop.is_set():
        result = subprocess.run(['ps','-axo','pid,rss,comm'],capture_output=True,text=True)
        rows = [line.strip() for line in result.stdout.splitlines()
                if str(ROOT/'.local/runtime') in line or '.local/runtime/ollama' in line]
        samples.append({'time':time.time(),'process_rss_kib':rows})
        stop.wait(1)

def sample_network():
    while not stop.is_set():
        try:
            power = subprocess.run([NET,'-getairportpower',DEVICE],capture_output=True,text=True,timeout=10)
            route = subprocess.run(['/sbin/route','-n','get','default'],capture_output=True,text=True,timeout=10)
            network_samples.append({'time':time.time(), 'wifi_power':power.stdout.strip(),
                                    'has_default_route':'interface:' in route.stdout})
        except Exception as exc:
            network_samples.append({'time':time.time(),'error':str(exc)})
        stop.wait(2)

watchdog = threading.Timer(600, lambda: subprocess.run([NET,'-setairportpower',DEVICE,'on'],capture_output=True))
watchdog.daemon = True
try:
    watchdog.start()
    changed = command([NET,'-setairportpower',DEVICE,'off'])
    time.sleep(3)
    power = command([NET,'-getairportpower',DEVICE])
    route = command(['/sbin/route','-n','get','default'])
    route6 = command(['/sbin/route','-n','get','-inet6','default'])
    probe = command(['/usr/bin/curl','--noproxy','*','--connect-timeout','3','--max-time','5','https://1.1.1.1'])
    if changed.returncode or 'Off' not in power.stdout or 'interface:' in route.stdout or probe.returncode == 0:
        raise RuntimeError('Physical offline state not established; tests not run.')
    if 'interface:' in route6.stdout:
        raise RuntimeError('IPv6 default route remains; offline state not verified.')
    status['disconnection_verified'] = True
    threading.Thread(target=sample_memory,daemon=True).start()
    threading.Thread(target=sample_network,daemon=True).start()
    print('Wi-Fi off. Starting fresh local CLI processes. Evidence: '+str(OUT),flush=True)
    code = record([sys.executable,'-u',str(ROOT/'scripts/evaluate.py')],540,'terminal')
    status['evaluation_exit_code'] = code
    power_after = command([NET,'-getairportpower',DEVICE])
    route_after = command(['/sbin/route','-n','get','default'])
    evaluations = sorted(set((ROOT/'evidence/evaluations').glob('*'))-before)
    status['evaluation_directories'] = [str(p.relative_to(ROOT)) for p in evaluations]
    required = {'help','ingest','ask-1','ask-2','ask-3','ask-4','chat','chat-isolation',
                'search','reingest','audit','reingestion_preserves_files'}
    complete = False
    if len(evaluations)==1 and (evaluations[0]/'results.json').exists():
        results = json.loads((evaluations[0]/'results.json').read_text())
        complete = required <= {r['label'] for r in results} and all(
            r.get('exit_code',0)==0 and r.get('passed') is not False for r in results)
        complete = complete and all((ROOT/f).exists() for r in results for f in r.get('records',[]))
        complete = complete and all(r.get('records') for r in results
                                    if r['label'] in {'ingest','ask-1','ask-2','ask-3','ask-4','chat','search'})
    status['verified'] = bool(code==0 and complete and 'Off' in power_after.stdout
                              and 'interface:' not in route_after.stdout)
    status['network_samples_all_offline'] = bool(network_samples) and all(
        'Off' in s.get('wifi_power','') and not s.get('has_default_route', True)
        for s in network_samples)
    status['verified'] = status['verified'] and status['network_samples_all_offline']
    status['answer_quality'] = 'Requires separate source-by-source review.'
    processes = subprocess.run(['ps','-axo','pid,comm'],capture_output=True,text=True)
    for line in processes.stdout.splitlines():
        if str(ROOT/'.local/runtime/llama-server') in line:
            sample_path = ROOT/'.local'/('footprint-'+STAMP+'.txt')
            subprocess.run(['/usr/bin/sample',line.split()[0],'1','1','-file',str(sample_path)],
                           capture_output=True,text=True,timeout=15)
            if sample_path.exists():
                status['physical_footprint_snapshot'] = [
                    x for x in sample_path.read_text().splitlines() if x.startswith('Physical footprint')]
except Exception as exc:
    status['error'] = str(exc)
finally:
    stop.set()
    restored = command([NET,'-setairportpower',DEVICE,'on'])
    status['wifi_restore_exit_code'] = restored.returncode
    status['wifi_power_after_restore'] = command([NET,'-getairportpower',DEVICE]).stdout.strip()
    watchdog.cancel()
    status['finished'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (OUT/'status.json').write_text(json.dumps(status,indent=2)+'\n')
    (OUT/'memory-samples.json').write_text(json.dumps(samples,indent=2)+'\n')
    (OUT/'network-samples.json').write_text(json.dumps(network_samples,indent=2)+'\n')
    log.close()
    latest = ROOT/'evidence/offline'
    if latest.exists():
        shutil.copytree(latest,ROOT/'evidence/offline-runs'/('previous-'+STAMP))
    latest.mkdir(exist_ok=True)
    for path in OUT.iterdir(): shutil.copy2(path,latest/path.name)
    print(json.dumps(status,indent=2),flush=True)
if not status['verified']: sys.exit(1)
