# Verified offline evaluation

The fresh CLI evaluation ran on September 29, 2026, about 11:43–11:46 p.m. Pacific time (September 30 UTC). Wi-Fi was switched off before launching the evaluator. The external connection probe failed, there was no IPv4 or IPv6 default route at startup, all periodic network samples remained offline, and Wi-Fi was still off when testing ended. The script then restored Wi-Fi and confirmed its power was on.

[Run manifest](../../offline-runs/20260930T064338904897Z/status.json) · [network log](../../offline-runs/20260930T064338904897Z/network.txt) · [periodic network samples](../../offline-runs/20260930T064338904897Z/network-samples.json) · [terminal transcript](../../offline-runs/20260930T064338904897Z/terminal.txt) · [actual terminal recording](../../offline-runs/20260930T064338904897Z/terminal.cast).

## Research answers and citations

- [Question 1](cards/ask-1.md): Pass. The environment variable, configuration alternative, restart instruction, and log message are all supported by S1, FAQ lines 165–208. The expected evidence was retrieved.
- [Question 2](cards/ask-2.md): Grounded, with limited explanatory depth. S1 supports the increased memory requirement of a larger context window. S2 supports increased context allocation with parallel requests. The answer does not explain the underlying storage mechanism, which these passages do not establish, and does not invent a byte formula. The expected evidence was retrieved.
- [Question 3](cards/ask-3.md): Pass within the evidence's scope. S1 supports text-to-vector representation, vector storage, and cosine similarity. The first sentence is repetitive, and the answer covers the retrieval component rather than the full answer-generation stage of RAG. The expected evidence was retrieved.
- [Question 4](cards/ask-4.md): Pass. Gemma explicitly returned insufficient evidence for a speed prediction on this user's computer. Measurements outside the vault were not retrieved as original evidence.

Citation labels in the three answerable responses point to passages supporting the material claims. All answers and retrieved passages remain in the unmodified JSON records linked from the cards. Per-call `offline_verified: false` means the CLI itself does not assert network state; the independently recorded run manifest and network samples establish disconnection for these calls.

## Mode boundaries and ingestion

[Chat transcript](chat.txt): both capability questions received accurate descriptions of Wren's text and wiki functions, with no retrieval, unrelated citations, or insufficient-evidence refusal. The invitation uses placeholders rather than invented personal facts. The follow-up produces one shorter invitation using the prior conversation.

[Chat isolation](chat-isolation.txt): the fictional project code supplied only in chat is unavailable to ask, which responds with insufficient evidence. [Search](search.txt) returns original passages and paths with no generated answer; the saved search record has `model_called: false`.

[Ingestion](ingest.txt): Gemma regenerated the embeddings note while disconnected. The prior version was backed up. The generated summary and seven details were checked against the unchanged embeddings original and are supported. Its review property was then marked reviewed. No original source was edited.

[Re-ingestion](reingest.txt) preserved all Markdown hashes without creating duplicate notes or restoring machine-style names. The [vault audit](audit.txt) found no missing or ambiguous links in the curated notes. Source hashes remain recorded in the catalog.

## Measured performance

| Operation | End-to-end seconds |
|---|---:|
| Ingest embeddings source | 43.343 |
| Ask 1 | 28.329 |
| Ask 2 | 21.171 |
| Ask 3 | 21.541 |
| Unsupported ask | 16.417 |
| Raw search | 0.487 |

These are measured command durations, including retrieval and output saving, for this run. The runtime process sample reported a physical footprint of 3.4 GB and a process-lifetime peak of 3.5 GB. The peak is not an isolated benchmark-window peak and is not total system memory use. Ollama's GPU/model allocation and the Python CLI's peak RSS are distinct measurements retained in each raw record. System activity and model startup can change response times.

## What changed after failed attempts

Earlier attempts exposed recorder startup problems and cloud-offloaded project files. The recorder now captures a real pseudoterminal as a timed asciicast file. The project was set to Keep Downloaded in Finder, and the runner refuses to disconnect if required files are still cloud placeholders. A subsequent attempt finished all commands but detected Wi-Fi reconnected early; that attempt remains unverified. This run completed with all sampled network states offline.
