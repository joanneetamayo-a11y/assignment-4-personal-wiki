# ask-4 evidence card

Question: What exact response time will Gemma E2B achieve on Joanne's MacBook Air?

Expected behavior: Insufficient evidence. Original documentation contains no benchmark of this person's computer.

Expected source: None; unsupported question

Expected evidence: No supporting passage in the originals

Execution: local. Timestamp: 20260930T064554662411Z.

Model identity and measurement:

```json
{
  "identity": {
    "model": "gemma4:e2b",
    "digest": "7fbdbf8f5e45a75bb122155ed546e765b4d9c53a1285f62fd9f506baa1c5a47e",
    "details": {
      "parent_model": "",
      "format": "gguf",
      "family": "gemma4",
      "families": [
        "gemma4"
      ],
      "parameter_size": "5.1B",
      "quantization_level": "Q4_K_M",
      "context_length": 131072,
      "embedding_length": 1536
    },
    "download_bytes": 7162405886,
    "runtime": {
      "version": "0.34.4"
    },
    "execution": "local"
  },
  "metrics": {
    "elapsed_seconds": 16.126,
    "cli_peak_rss_bytes": 33177600,
    "loaded_models": [
      {
        "name": "gemma4:e2b",
        "model": "gemma4:e2b",
        "size": 1717294857,
        "digest": "7fbdbf8f5e45a75bb122155ed546e765b4d9c53a1285f62fd9f506baa1c5a47e",
        "details": {
          "parent_model": "",
          "format": "gguf",
          "family": "gemma4",
          "families": [
            "gemma4"
          ],
          "parameter_size": "5.1B",
          "quantization_level": "Q4_K_M"
        },
        "expires_at": "2026-09-29T23:50:54.642517-07:00",
        "size_vram": 1717294857,
        "context_length": 4096
      }
    ],
    "total_duration": 16114176791,
    "load_duration": 1912791,
    "prompt_eval_count": 1562,
    "eval_count": 12,
    "eval_duration": 1096649000
  },
  "options": {
    "num_ctx": 4096,
    "num_predict": 650,
    "temperature": 0.2,
    "seed": 42
  },
  "thinking": false
}
```

## Actual displayed answer

Insufficient evidence in the indexed sources to answer this question.

## Retrieved original passages

### [S1] vault/raw/Ollama FAQ.md, lines 299–323

[Open original](../../../../vault/raw/Ollama%20FAQ.md). Retrieval score: 3.8707.

> - a duration string (such as "10m" or "24h")
> - a number in seconds (such as 3600)
> - any negative number which will keep the model loaded in memory (e.g. -1 or "-1m")
> - '0' which will unload the model immediately after generating a response
> 
> For example, to preload a model and leave it in memory use:
> 
> ```shell
> curl http://localhost:11434/api/generate -d '{"model": "llama3.2", "keep_alive": -1}'
> ```
> 
> To unload the model and free up memory use:
> 
> ```shell
> curl http://localhost:11434/api/generate -d '{"model": "llama3.2", "keep_alive": 0}'
> ```
> 
> Alternatively, you can change the amount of time all models are loaded into memory by setting the `OLLAMA_KEEP_ALIVE` environment variable when starting the Ollama server. The `OLLAMA_KEEP_ALIVE` variable uses the same parameter types as the `keep_alive` parameter types mentioned above. Refer to the section explaining [how to configure the Ollama server](#how-do-i-configure-ollama-server) to correctly set the environment variable.
> 
> The `keep_alive` API parameter with the `/api/generate` and `/api/chat` API endpoints will override the `OLLAMA_KEEP_ALIVE` setting.
> 
> ## How do I manage the maximum number of requests the Ollama server can queue?
> 
> If too many requests are sent to the server, it will respond with a 503 error indicating the server is overloaded. You can adjust how many requests may be queued by setting `OLLAMA_MAX_QUEUE`.
> 

### [S2] vault/raw/Ollama FAQ.md, lines 264–298

[Open original](../../../../vault/raw/Ollama%20FAQ.md). Retrieval score: 3.3399.

> Click on `Configure` and open the `Advanced` tab. Search through each of the properties until you find `Large Send Offload Version 2 (IPv4)` and `Large Send Offload Version 2 (IPv6)`. _Disable_ both of these
> properties.
> 
> ## How can I preload a model into Ollama to get faster response times?
> 
> If you are using the API you can preload a model by sending the Ollama server an empty request. This works with both the `/api/generate` and `/api/chat` API endpoints.
> 
> To preload the mistral model using the generate endpoint, use:
> 
> ```shell
> curl http://localhost:11434/api/generate -d '{"model": "mistral"}'
> ```
> 
> To use the chat completions endpoint, use:
> 
> ```shell
> curl http://localhost:11434/api/chat -d '{"model": "mistral"}'
> ```
> 
> To preload a model using the CLI, use the command:
> 
> ```shell
> ollama run llama3.2 ""
> ```
> 
> ## How do I keep a model loaded in memory or make it unload immediately?
> 
> By default models are kept in memory for 5 minutes before being unloaded. This allows for quicker response times if you're making numerous requests to the LLM. If you want to immediately unload a model from memory, use the `ollama stop` command:
> 
> ```shell
> ollama stop llama3.2
> ```
> 
> If you're using the API, use the `keep_alive` parameter with the `/api/generate` and `/api/chat` endpoints to set the amount of time that a model stays in memory. The `keep_alive` parameter can be set to:
> 

### [S3] vault/raw/Ollama FAQ.md, lines 335–345

[Open original](../../../../vault/raw/Ollama%20FAQ.md). Retrieval score: 2.6479.

> - `OLLAMA_NUM_PARALLEL` - The maximum number of parallel requests each model will process at the same time, default 1.  Required RAM will scale by `OLLAMA_NUM_PARALLEL` * `OLLAMA_CONTEXT_LENGTH`.
> - `OLLAMA_MAX_QUEUE` - The maximum number of requests Ollama will queue when busy before rejecting additional requests. The default is 512
> 
> Note: Windows with Radeon GPUs currently default to 1 model maximum due to limitations in ROCm v5.7 for available VRAM reporting. Once ROCm v6.2 is available, Windows Radeon will follow the defaults above. You may enable concurrent model loads on Radeon on Windows, but ensure you don't load more models than will fit into your GPU's VRAM.
> 
> ## How does Ollama load models on multiple GPUs?
> 
> When loading a new model, Ollama evaluates the required VRAM for the model against what is currently available. If the model will entirely fit on any single GPU, Ollama will load the model on that GPU. This typically provides the best performance as it reduces the amount of data transferring across the PCI bus during inference. If the model does not fit entirely on one GPU, then it will be spread across all the available GPUs.
> 
> ## How can I enable Flash Attention?
> 

### [S4] vault/raw/Ollama FAQ.md, lines 324–334

[Open original](../../../../vault/raw/Ollama%20FAQ.md). Retrieval score: 2.4103.

> ## How does Ollama handle concurrent requests?
> 
> Ollama supports two levels of concurrent processing. If your system has sufficient available memory (system memory when using CPU inference, or VRAM for GPU inference) then multiple models can be loaded at the same time. For a given model, if there is sufficient available memory when the model is loaded, it is configured to allow parallel request processing.
> 
> If there is insufficient available memory to load a new model request while one or more models are already loaded, all new requests will be queued until the new model can be loaded. As prior models become idle, one or more will be unloaded to make room for the new model. Queued requests will be processed in order. When using GPU inference new models must be able to completely fit in VRAM to allow concurrent model loads.
> 
> Parallel request processing for a given model results in increasing the context size by the number of parallel requests. For example, a 2K context with 4 parallel requests will result in an 8K context and additional memory allocation.
> 
> The following server settings may be used to adjust how Ollama handles concurrent requests on most platforms:
> 
> - `OLLAMA_MAX_LOADED_MODELS` - The maximum number of models that can be loaded concurrently provided they fit in available memory. The default is 3 \* the number of GPUs or 3 for CPU inference.

## Citation check and review

```json
{
  "labels": [],
  "unknown": [],
  "valid_labels": false,
  "semantic_support": "Requires source-by-source review; label validity is not proof of support."
}
```

The originals contain no timing measurement for this specific computer. The required behavior is insufficient evidence.

The assessment of actual claims is recorded in the evaluation review; valid labels alone do not prove support.

[Unmodified JSON record](../../../runs/20260930T064554662411Z-ask.json)
