# ask-2 evidence card

Question: Why does increasing the context length require more memory?

Expected behavior: Explain only the documented relation between context tokens and memory. Do not invent a byte formula.

Expected source: vault/raw/Ollama Context Length.md

Expected evidence: Setting a larger context length will increase the amount of memory required to run a model.

Execution: local. Timestamp: 20260930T064516699517Z.

Model identity and measurement:

```json
{
  "identity": {
    "model": "gemma4:e2b",
    "digest": "7fbdbf8f5e45a75bb122155ed546e765b4d9c53a1285f62fd9f506baa1c5a47e",
    "details": {
      "parent_model": "",
      "format": "gguf",
      "family": "gemma4",
      "families": [
        "gemma4"
      ],
      "parameter_size": "5.1B",
      "quantization_level": "Q4_K_M",
      "context_length": 131072,
      "embedding_length": 1536
    },
    "download_bytes": 7162405886,
    "runtime": {
      "version": "0.34.4"
    },
    "execution": "local"
  },
  "metrics": {
    "elapsed_seconds": 20.912,
    "cli_peak_rss_bytes": 33570816,
    "loaded_models": [
      {
        "name": "gemma4:e2b",
        "model": "gemma4:e2b",
        "size": 1717294857,
        "digest": "7fbdbf8f5e45a75bb122155ed546e765b4d9c53a1285f62fd9f506baa1c5a47e",
        "details": {
          "parent_model": "",
          "format": "gguf",
          "family": "gemma4",
          "families": [
            "gemma4"
          ],
          "parameter_size": "5.1B",
          "quantization_level": "Q4_K_M"
        },
        "expires_at": "2026-09-29T23:50:16.692433-07:00",
        "size_vram": 1717294857,
        "context_length": 4096
      }
    ],
    "total_duration": 20908423708,
    "load_duration": 1747583,
    "prompt_eval_count": 1594,
    "eval_count": 48,
    "eval_duration": 5221538000
  },
  "options": {
    "num_ctx": 4096,
    "num_predict": 650,
    "temperature": 0.2,
    "seed": 42
  },
  "thinking": false
}
```

## Actual displayed answer

Setting a larger context length will increase the amount of memory required to run a model [S1]. Parallel request processing for a given model results in increasing the context size by the number of parallel requests and additional memory allocation [S2].

## Retrieved original passages

### [S1] vault/raw/Ollama Context Length.md, lines 1–39

[Open original](../../../../vault/raw/Ollama%20Context%20Length.md). Retrieval score: 7.647.

> ---
> title: Context length
> ---
> 
> Context length is the maximum number of tokens that the model has access to in memory.  
> 
> <Note>
>   Ollama defaults to the following context lengths based on VRAM:
>     - < 24 GiB VRAM: 4k context
>     - 24-48 GiB VRAM: 32k context
>     - &gt;= 48 GiB VRAM: 256k context
> </Note>
> 
> Tasks which require large context like web search, agents, and coding tools should be set to at least 64000 tokens.
> 
> ## Setting context length
> 
> Setting a larger context length will increase the amount of memory required to run a model. Ensure you have enough VRAM available to increase the context length.
> 
> Cloud models are set to their maximum context length by default.
> 
> ### App
> 
> Change the slider in the Ollama app under settings to your desired context length.
> ![Context length in Ollama app](./images/ollama-settings.png)
> 
> ### CLI
> If editing the context length for Ollama is not possible, the context length can also be updated when serving Ollama.  
> ```
> OLLAMA_CONTEXT_LENGTH=64000 ollama serve
> ```
> 
> ### Check allocated context length and model offloading
> For best performance, use the maximum context length for a model, and avoid offloading the model to CPU. Verify the split under `PROCESSOR` using `ollama ps`.
> ```
> ollama ps
> ```
> ```
> NAME             ID              SIZE      PROCESSOR    CONTEXT    UNTIL

### [S2] vault/raw/Ollama FAQ.md, lines 324–334

[Open original](../../../../vault/raw/Ollama%20FAQ.md). Retrieval score: 7.488.

> ## How does Ollama handle concurrent requests?
> 
> Ollama supports two levels of concurrent processing. If your system has sufficient available memory (system memory when using CPU inference, or VRAM for GPU inference) then multiple models can be loaded at the same time. For a given model, if there is sufficient available memory when the model is loaded, it is configured to allow parallel request processing.
> 
> If there is insufficient available memory to load a new model request while one or more models are already loaded, all new requests will be queued until the new model can be loaded. As prior models become idle, one or more will be unloaded to make room for the new model. Queued requests will be processed in order. When using GPU inference new models must be able to completely fit in VRAM to allow concurrent model loads.
> 
> Parallel request processing for a given model results in increasing the context size by the number of parallel requests. For example, a 2K context with 4 parallel requests will result in an 8K context and additional memory allocation.
> 
> The following server settings may be used to adjust how Ollama handles concurrent requests on most platforms:
> 
> - `OLLAMA_MAX_LOADED_MODELS` - The maximum number of models that can be loaded concurrently provided they fit in available memory. The default is 3 \* the number of GPUs or 3 for CPU inference.

### [S3] vault/raw/Ollama FAQ.md, lines 1–58

[Open original](../../../../vault/raw/Ollama%20FAQ.md). Retrieval score: 5.7764.

> ---
> title: FAQ
> ---
> 
> ## How can I upgrade Ollama?
> 
> Ollama on macOS and Windows will automatically download updates. Click on the taskbar or menubar item and then click "Restart to update" to apply the update. Updates can also be installed by downloading the latest version [manually](https://ollama.com/download/).
> 
> On Linux, re-run the install script:
> 
> ```shell
> curl -fsSL https://ollama.com/install.sh | sh
> ```
> 
> ## How can I view the logs?
> 
> Review the [Troubleshooting](./troubleshooting.mdx) docs for more about using logs.
> 
> ## Is my GPU compatible with Ollama?
> 
> Please refer to the [GPU docs](./gpu.mdx).
> 
> ## How can I specify the context window size?
> 
> By default, Ollama uses a context window size of 4096 tokens.
> 
> This can be overridden with the `OLLAMA_CONTEXT_LENGTH` environment variable. For example, to set the default context window to 8K, use:
> 
> ```shell
> OLLAMA_CONTEXT_LENGTH=8192 ollama serve
> ```
> 
> To change this when using `ollama run`, use `/set parameter`:
> 
> ```shell
> /set parameter num_ctx 4096
> ```
> 
> When using the API, specify the `num_ctx` parameter:
> 
> ```shell
> curl http://localhost:11434/api/generate -d '{
>   "model": "llama3.2",
>   "prompt": "Why is the sky blue?",
>   "options": {
>     "num_ctx": 4096
>   }
> }'
> ```
> 
> ## How can I tell if my model was loaded onto the GPU?
> 
> Use the `ollama ps` command to see what models are currently loaded into memory.
> 
> ```shell
> ollama ps
> ```
> 

### [S4] vault/raw/Ollama FAQ.md, lines 346–366

[Open original](../../../../vault/raw/Ollama%20FAQ.md). Retrieval score: 4.813.

> Flash Attention is a feature of most modern models that can significantly reduce memory usage as the context size grows. Ollama uses Flash Attention automatically when the selected backend and devices support it. To force Flash Attention on, set `OLLAMA_FLASH_ATTENTION=1` when starting the Ollama server. To disable it, set `OLLAMA_FLASH_ATTENTION=0`.
> 
> ## How can I set the quantization type for the K/V cache?
> 
> The K/V context cache can be quantized to significantly reduce memory usage when Flash Attention is enabled.
> 
> To use quantized K/V cache with Ollama you can set the following environment variable:
> 
> - `OLLAMA_KV_CACHE_TYPE` - The quantization type for the K/V cache. Default is `f16`.
> 
> <Note>
>   Currently this is a global option - meaning all models will run with the
>   specified quantization type.
> </Note>
> 
> The currently available K/V cache quantization types are:
> 
> - `f16` - high precision and memory usage (default).
> - `q8_0` - 8-bit quantization, uses approximately 1/2 the memory of `f16` with a very small loss in precision, this usually has no noticeable impact on the model's quality (recommended if not using f16).
> - `q4_0` - 4-bit quantization, uses approximately 1/4 the memory of `f16` with a small-medium loss in precision that may be more noticeable at higher context sizes.
> 

## Citation check and review

```json
{
  "labels": [
    "S1",
    "S2"
  ],
  "unknown": [],
  "valid_labels": true,
  "semantic_support": "Requires source-by-source review; label validity is not proof of support."
}
```

Check the stated memory relationship and parallel-request claim separately. The source establishes that more context uses more memory; it does not supply a byte formula or detailed mechanism.

The assessment of actual claims is recorded in the evaluation review; valid labels alone do not prove support.

[Unmodified JSON record](../../../runs/20260930T064516699517Z-ask.json)
