# ask-3 evidence card

Question: How are embeddings used in a RAG pipeline?

Expected behavior: Describe embedding, retrieval, and evidence context only where supported, with citations.

Expected source: vault/raw/Ollama Embeddings.md

Expected evidence: Embeddings turn text into numeric vectors

Execution: local. Timestamp: 20260930T064538232233Z.

Model identity and measurement:

```json
{
  "identity": {
    "model": "gemma4:e2b",
    "digest": "7fbdbf8f5e45a75bb122155ed546e765b4d9c53a1285f62fd9f506baa1c5a47e",
    "details": {
      "parent_model": "",
      "format": "gguf",
      "family": "gemma4",
      "families": [
        "gemma4"
      ],
      "parameter_size": "5.1B",
      "quantization_level": "Q4_K_M",
      "context_length": 131072,
      "embedding_length": 1536
    },
    "download_bytes": 7162405886,
    "runtime": {
      "version": "0.34.4"
    },
    "execution": "local"
  },
  "metrics": {
    "elapsed_seconds": 21.284,
    "cli_peak_rss_bytes": 33275904,
    "loaded_models": [
      {
        "name": "gemma4:e2b",
        "model": "gemma4:e2b",
        "size": 1717294857,
        "digest": "7fbdbf8f5e45a75bb122155ed546e765b4d9c53a1285f62fd9f506baa1c5a47e",
        "details": {
          "parent_model": "",
          "format": "gguf",
          "family": "gemma4",
          "families": [
            "gemma4"
          ],
          "parameter_size": "5.1B",
          "quantization_level": "Q4_K_M"
        },
        "expires_at": "2026-09-29T23:50:38.214069-07:00",
        "size_vram": 1717294857,
        "context_length": 4096
      }
    ],
    "total_duration": 21271842917,
    "load_duration": 4031875,
    "prompt_eval_count": 1589,
    "eval_count": 53,
    "eval_duration": 5986499000
  },
  "options": {
    "num_ctx": 4096,
    "num_predict": 650,
    "temperature": 0.2,
    "seed": 42
  },
  "thinking": false
}
```

## Actual displayed answer

Embeddings are used in RAG pipelines for semantic search, retrieval, and RAG [S1]. Embeddings convert text into numeric vectors that can be stored in a vector database, searched using cosine similarity, or utilized in RAG pipelines [S1].

## Retrieved original passages

### [S1] vault/raw/Ollama Embeddings.md, lines 1–49

[Open original](../../../../vault/raw/Ollama%20Embeddings.md). Retrieval score: 6.6087.

> > ## Documentation Index
> > Fetch the complete documentation index at: https://docs.ollama.com/llms.txt
> > Use this file to discover all available pages before exploring further.
> 
> # Embeddings
> 
> > Generate text embeddings for semantic search, retrieval, and RAG.
> 
> Embeddings turn text into numeric vectors you can store in a vector database, search with cosine similarity, or use in RAG pipelines. The vector length depends on the model (typically 384–1024 dimensions).
> 
> ## Recommended models
> 
> * [embeddinggemma](https://ollama.com/library/embeddinggemma)
> * [qwen3-embedding](https://ollama.com/library/qwen3-embedding)
> * [all-minilm](https://ollama.com/library/all-minilm)
> 
> ## Generate embeddings
> 
> <Tabs>
>   <Tab title="CLI">
>     Generate embeddings directly from the command line:
> 
>     ```shell theme={"system"}
>     ollama run embeddinggemma "Hello world"
>     ```
> 
>     You can also pipe text to generate embeddings:
> 
>     ```shell theme={"system"}
>     echo "Hello world" | ollama run embeddinggemma
>     ```
> 
>     Output is a JSON array.
>   </Tab>
> 
>   <Tab title="cURL">
>     ```shell theme={"system"}
>     curl -X POST http://localhost:11434/api/embed \
>       -H "Content-Type: application/json" \
>       -d '{
>         "model": "embeddinggemma",
>         "input": "The quick brown fox jumps over the lazy dog."
>       }'
>     ```
>   </Tab>
> 
>   <Tab title="Python">
>     ```python theme={"system"}
>     import ollama

### [S2] vault/raw/Ollama Embeddings.md, lines 50–109

[Open original](../../../../vault/raw/Ollama%20Embeddings.md). Retrieval score: 2.9538.

> 
>     single = ollama.embed(
>       model='embeddinggemma',
>       input='The quick brown fox jumps over the lazy dog.'
>     )
>     print(len(single['embeddings'][0]))  # vector length
>     ```
>   </Tab>
> 
>   <Tab title="JavaScript">
>     ```javascript theme={"system"}
>     import ollama from 'ollama'
> 
>     const single = await ollama.embed({
>       model: 'embeddinggemma',
>       input: 'The quick brown fox jumps over the lazy dog.',
>     })
>     console.log(single.embeddings[0].length) // vector length
>     ```
>   </Tab>
> </Tabs>
> 
> <Note>
>   The `/api/embed` endpoint returns L2‑normalized (unit‑length) vectors.
> </Note>
> 
> ## Generate a batch of embeddings
> 
> Pass an array of strings to `input`.
> 
> <Tabs>
>   <Tab title="cURL">
>     ```shell theme={"system"}
>     curl -X POST http://localhost:11434/api/embed \
>       -H "Content-Type: application/json" \
>       -d '{
>         "model": "embeddinggemma",
>         "input": [
>           "First sentence",
>           "Second sentence",
>           "Third sentence"
>         ]
>       }'
>     ```
>   </Tab>
> 
>   <Tab title="Python">
>     ```python theme={"system"}
>     import ollama
> 
>     batch = ollama.embed(
>       model='embeddinggemma',
>       input=[
>         'The quick brown fox jumps over the lazy dog.',
>         'The five boxing wizards jump quickly.',
>         'Jackdaws love my big sphinx of quartz.',
>       ]
>     )
>     print(len(batch['embeddings']))  # number of vectors
>     ```

### [S3] vault/raw/Ollama Embeddings.md, lines 110–132

[Open original](../../../../vault/raw/Ollama%20Embeddings.md). Retrieval score: 2.2638.

>   </Tab>
> 
>   <Tab title="JavaScript">
>     ```javascript theme={"system"}
>     import ollama from 'ollama'
> 
>     const batch = await ollama.embed({
>       model: 'embeddinggemma',
>       input: [
>         'The quick brown fox jumps over the lazy dog.',
>         'The five boxing wizards jump quickly.',
>         'Jackdaws love my big sphinx of quartz.',
>       ],
>     })
>     console.log(batch.embeddings.length) // number of vectors
>     ```
>   </Tab>
> </Tabs>
> 
> ## Tips
> 
> * Use cosine similarity for most semantic search use cases.
> * Use the same embedding model for both indexing and querying.

### [S4] vault/raw/Ollama FAQ.md, lines 209–243

[Open original](../../../../vault/raw/Ollama%20FAQ.md). Retrieval score: 2.0082.

> ngrok http 11434 --host-header="localhost:11434"
> ```
> 
> ## How can I use Ollama with Cloudflare Tunnel?
> 
> To use Ollama with Cloudflare Tunnel, use the `--url` and `--http-host-header` flags:
> 
> ```shell
> cloudflared tunnel --url http://localhost:11434 --http-host-header="localhost:11434"
> ```
> 
> ## How can I allow additional web origins to access Ollama?
> 
> Ollama allows cross-origin requests from `127.0.0.1` and `0.0.0.0` by default. Additional origins can be configured with `OLLAMA_ORIGINS`.
> 
> For browser extensions, you'll need to explicitly allow the extension's origin pattern. Set `OLLAMA_ORIGINS` to include `chrome-extension://*`, `moz-extension://*`, and `safari-web-extension://*` if you wish to allow all browser extensions access, or specific extensions as needed:
> 
> ```
> # Allow all Chrome, Firefox, and Safari extensions
> OLLAMA_ORIGINS=chrome-extension://*,moz-extension://*,safari-web-extension://* ollama serve
> ```
> 
> Refer to the section [above](#how-do-i-configure-ollama-server) for how to set environment variables on your platform.
> 
> ## Where are models stored?
> 
> - macOS: `~/.ollama/models`
> - Linux: `/usr/share/ollama/.ollama/models`
> - Windows: `C:\Users\%username%\.ollama\models`
> 
> ### How do I set them to a different location?
> 
> If a different directory needs to be used, set the environment variable `OLLAMA_MODELS` to the chosen directory.
> 
> <Note>

## Citation check and review

```json
{
  "labels": [
    "S1"
  ],
  "unknown": [],
  "valid_labels": true,
  "semantic_support": "Requires source-by-source review; label validity is not proof of support."
}
```

Check vector representation, storage, and cosine similarity against the embeddings introduction. This source supports the retrieval component, not a complete account of answer generation.

The assessment of actual claims is recorded in the evaluation review; valid labels alone do not prove support.

[Unmodified JSON record](../../../runs/20260930T064538232233Z-ask.json)
