# Research evidence cards

- [ask-1](ask-1.md): How can I disable Ollama cloud features using an environment variable?
- [ask-2](ask-2.md): Why does increasing the context length require more memory?
- [ask-3](ask-3.md): How are embeddings used in a RAG pipeline?
- [ask-4](ask-4.md): What exact response time will Gemma E2B achieve on Joanne's MacBook Air?

These cards reproduce actual saved outputs. See the run network manifest for offline verification and the separate review for answer quality.
