# ask-1 evidence card

Question: How can I disable Ollama cloud features using an environment variable?

Expected behavior: State the variable and restart requirement, with source citations.

Expected source: vault/raw/Ollama FAQ.md

Expected evidence: OLLAMA_NO_CLOUD=1

Execution: local. Timestamp: 20260930T064455510811Z.

Model identity and measurement:

```json
{
  "identity": {
    "model": "gemma4:e2b",
    "digest": "7fbdbf8f5e45a75bb122155ed546e765b4d9c53a1285f62fd9f506baa1c5a47e",
    "details": {
      "parent_model": "",
      "format": "gguf",
      "family": "gemma4",
      "families": [
        "gemma4"
      ],
      "parameter_size": "5.1B",
      "quantization_level": "Q4_K_M",
      "context_length": 131072,
      "embedding_length": 1536
    },
    "download_bytes": 7162405886,
    "runtime": {
      "version": "0.34.4"
    },
    "execution": "local"
  },
  "metrics": {
    "elapsed_seconds": 27.941,
    "cli_peak_rss_bytes": 33341440,
    "loaded_models": [
      {
        "name": "gemma4:e2b",
        "model": "gemma4:e2b",
        "size": 1717294857,
        "digest": "7fbdbf8f5e45a75bb122155ed546e765b4d9c53a1285f62fd9f506baa1c5a47e",
        "details": {
          "parent_model": "",
          "format": "gguf",
          "family": "gemma4",
          "families": [
            "gemma4"
          ],
          "parameter_size": "5.1B",
          "quantization_level": "Q4_K_M"
        },
        "expires_at": "2026-09-29T23:49:55.4994-07:00",
        "size_vram": 1717294857,
        "context_length": 4096
      }
    ],
    "total_duration": 27936252959,
    "load_duration": 3813709,
    "prompt_eval_count": 1721,
    "eval_count": 101,
    "eval_duration": 10988921000
  },
  "options": {
    "num_ctx": 4096,
    "num_predict": 650,
    "temperature": 0.2,
    "seed": 42
  },
  "thinking": false
}
```

## Actual displayed answer

You can disable Ollama's cloud features by setting the environment variable `OLLAMA_NO_CLOUD` to `1` [S1]. Alternatively, you can set `"disable_ollama_cloud": true` in the `~/.ollama/server.json` file [S1]. After making this change, you must restart Ollama [S1]. Once disabled, Ollama's logs will indicate that "Ollama cloud disabled: true" [S1].

## Retrieved original passages

### [S1] vault/raw/Ollama FAQ.md, lines 165–208

[Open original](../../../../vault/raw/Ollama%20FAQ.md). Retrieval score: 10.9194.

> Ollama can run in local only mode by disabling Ollama's cloud features. By turning off Ollama's cloud features, you will lose the ability to use Ollama's cloud models and web search. 
> 
> Set `disable_ollama_cloud` in `~/.ollama/server.json`:
> 
> ```json
> {
>   "disable_ollama_cloud": true
> }
> ```
> 
> You can also set the environment variable:
> 
> ```shell
> OLLAMA_NO_CLOUD=1
> ```
> 
> Restart Ollama after changing configuration. Once disabled, Ollama's logs will show `Ollama cloud disabled: true`. 
> 
> ## How can I expose Ollama on my network?
> 
> Ollama binds 127.0.0.1 port 11434 by default. Change the bind address with the `OLLAMA_HOST` environment variable.
> 
> Refer to the section [above](#how-do-i-configure-ollama-server) for how to set environment variables on your platform.
> 
> ## How can I use Ollama with a proxy server?
> 
> Ollama runs an HTTP server and can be exposed using a proxy server such as Nginx. To do so, configure the proxy to forward requests and optionally set required headers (if not exposing Ollama on the network). For example, with Nginx:
> 
> ```nginx
> server {
>     listen 80;
>     server_name example.com;  # Replace with your domain or IP
>     location / {
>         proxy_pass http://localhost:11434;
>         proxy_set_header Host localhost:11434;
>     }
> }
> ```
> 
> ## How can I use Ollama with ngrok?
> 
> Ollama can be accessed using a range of tunneling apps. For example with Ngrok:
> 
> ```shell

### [S2] vault/raw/Ollama FAQ.md, lines 142–164

[Open original](../../../../vault/raw/Ollama%20FAQ.md). Retrieval score: 6.1943.

> Alternatively, the Docker daemon can be configured to use a proxy. Instructions are available for Docker Desktop on [macOS](https://docs.docker.com/desktop/settings/mac/#proxies), [Windows](https://docs.docker.com/desktop/settings/windows/#proxies), and [Linux](https://docs.docker.com/desktop/settings/linux/#proxies), and Docker [daemon with systemd](https://docs.docker.com/config/daemon/systemd/#httphttps-proxy).
> 
> Ensure the certificate is installed as a system certificate when using HTTPS. This may require a new Docker image when using a self-signed certificate.
> 
> ```dockerfile
> FROM ollama/ollama
> COPY my-ca.pem /usr/local/share/ca-certificates/my-ca.crt
> RUN update-ca-certificates
> ```
> 
> Build and run this image:
> 
> ```shell
> docker build -t ollama-with-ca .
> docker run -d -e HTTPS_PROXY=https://my.proxy.example.com -p 11434:11434 ollama-with-ca
> ```
> 
> ## Does Ollama send my prompts and answers back to ollama.com?
> 
> Ollama runs locally. We don't see your prompts or data when you run locally. When using cloud-hosted models, we process your prompts and responses to provide the service but do not store or log that content and never train on it. We collect basic account info and limited usage metadata to provide the service that does not include prompt or response content. We don't sell your data. You can delete your account anytime.
> 
> ## How do I disable Ollama Cloud features?
> 

### [S3] vault/raw/Ollama FAQ.md, lines 59–112

[Open original](../../../../vault/raw/Ollama%20FAQ.md). Retrieval score: 4.0932.

> <Info>
> 
> **Output**:
> 
> ```
> NAME        ID            SIZE    PROCESSOR   UNTIL
> llama3:70b  bcfb190ca3a7  42 GB   100% GPU    4 minutes from now
> ```
> </Info>
> 
> The `Processor` column will show which memory the model was loaded into:
> 
> - `100% GPU` means the model was loaded entirely into the GPU
> - `100% CPU` means the model was loaded entirely in system memory
> - `48%/52% CPU/GPU` means the model was loaded partially onto both the GPU and into system memory
> 
> ## How do I configure Ollama server?
> 
> Ollama server can be configured with environment variables.
> 
> ### Setting environment variables on Mac
> 
> If Ollama is run as a macOS application, environment variables should be set using `launchctl`:
> 
> 1. For each environment variable, call `launchctl setenv`.
> 
>    ```bash
>    launchctl setenv OLLAMA_HOST "0.0.0.0:11434"
>    ```
> 
> 2. Restart Ollama application.
> 
> ### Setting environment variables on Linux
> 
> If Ollama is run as a systemd service, environment variables should be set using `systemctl`:
> 
> 1. Edit the systemd service by calling `systemctl edit ollama.service`. This will open an editor.
> 
> 2. For each environment variable, add a line `Environment` under section `[Service]`:
> 
>    ```ini
>    [Service]
>    Environment="OLLAMA_HOST=0.0.0.0:11434"
>    ```
> 
> 3. Save and exit.
> 
> 4. Reload `systemd` and restart Ollama:
> 
>    ```shell
>    systemctl daemon-reload
>    systemctl restart ollama
>    ```
> 

### [S4] vault/raw/Ollama FAQ.md, lines 346–366

[Open original](../../../../vault/raw/Ollama%20FAQ.md). Retrieval score: 3.9813.

> Flash Attention is a feature of most modern models that can significantly reduce memory usage as the context size grows. Ollama uses Flash Attention automatically when the selected backend and devices support it. To force Flash Attention on, set `OLLAMA_FLASH_ATTENTION=1` when starting the Ollama server. To disable it, set `OLLAMA_FLASH_ATTENTION=0`.
> 
> ## How can I set the quantization type for the K/V cache?
> 
> The K/V context cache can be quantized to significantly reduce memory usage when Flash Attention is enabled.
> 
> To use quantized K/V cache with Ollama you can set the following environment variable:
> 
> - `OLLAMA_KV_CACHE_TYPE` - The quantization type for the K/V cache. Default is `f16`.
> 
> <Note>
>   Currently this is a global option - meaning all models will run with the
>   specified quantization type.
> </Note>
> 
> The currently available K/V cache quantization types are:
> 
> - `f16` - high precision and memory usage (default).
> - `q8_0` - 8-bit quantization, uses approximately 1/2 the memory of `f16` with a very small loss in precision, this usually has no noticeable impact on the model's quality (recommended if not using f16).
> - `q4_0` - 4-bit quantization, uses approximately 1/4 the memory of `f16` with a small-medium loss in precision that may be more noticeable at higher context sizes.
> 

## Citation check and review

```json
{
  "labels": [
    "S1"
  ],
  "unknown": [],
  "valid_labels": true,
  "semantic_support": "Requires source-by-source review; label validity is not proof of support."
}
```

Review the variable, configuration alternative, restart instruction, and log message against the cited FAQ passage.

The assessment of actual claims is recorded in the evaluation review; valid labels alone do not prove support.

[Unmodified JSON record](../../../runs/20260930T064455510811Z-ask.json)
