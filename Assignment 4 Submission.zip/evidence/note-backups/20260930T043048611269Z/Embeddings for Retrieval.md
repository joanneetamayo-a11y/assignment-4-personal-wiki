---
source_id: ollama-embeddings
source_sha256: 62d7c8ba5124825abd30fa10a532d92c4a2e35598c5e7f9549c5480411e95c92
review_status: reviewed
---

# Embeddings for Retrieval

Embeddings generate text embeddings for semantic search, retrieval, and RAG by turning text into numeric vectors. These vectors can be stored in a vector database and searched using cosine similarity.

## Details

- Embeddings turn text into numeric vectors.
- Embeddings are used for semantic search, retrieval, and RAG.
- Vector length depends on the model (typically 384–1024 dimensions).
- Recommended models include embeddinggemma, qwen3-embedding, and all-minilm.
- The `/api/embed` endpoint returns L2‑normalized (unit‑length) vectors.
- Cosine similarity should be used for most semantic search use cases.
- The same embedding model should be used for both indexing and querying.

## Sources

- [[raw/Ollama Embeddings.md|Original source]]
- Publisher: Ollama
- [Original publication](https://docs.ollama.com/capabilities/embeddings.md)

## Related notes

- [[Context Window Memory]] — A RAG workflow places selected search results in the model context.
- [[Local Runtime Settings]] — The same local runtime can host generation and embedding models.
