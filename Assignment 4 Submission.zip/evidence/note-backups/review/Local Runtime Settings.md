---
source_id: ollama-faq
source_sha256: 7fc6dd6825f927e7e9e41f4b0d3e58b979d3c03cb29783f697fdc79a1c07a4d1
review_status: pending
---

# Local Runtime Settings

Information regarding upgrading Ollama, managing context window size, GPU detection, server configuration, proxy usage, data privacy, and network exposure.

## Details

- Ollama on macOS and Windows automatically downloads updates; on Linux, re-run the install script to update.
- The default context window size is 4096 tokens, which can be overridden by the `OLLAMA_CONTEXT_LENGTH` environment variable or via `/set parameter` or API calls.
- GPU usage can be checked with `ollama ps`; the `Processor` column indicates if a model is loaded onto the GPU (e.g., `100% GPU`).
- Ollama server configuration uses environment variables, with specific instructions for macOS (`launchctl`), Linux (`systemd`), and Windows.
- Using a proxy requires setting the `HTTPS_PROXY` environment variable, and `HTTP_PROXY` should be avoided as Ollama only uses HTTPS for model pulls.
- Ollama can be run behind a proxy in Docker by setting `HTTPS_PROXY` in the container start command or configuring the Docker daemon.
- Ollama does not store or log prompts or responses when running locally; it collects only basic account info and usage metadata.
- Ollama cloud features can be disabled by setting `disable_ollama_cloud` in `~/.ollama/server.json` or setting the `OLLAMA_NO_CLOUD` environment variable.
- Ollama can be exposed on a network by changing the bind address using the `OLLAMA_HOST` environment variable.
- Ollama can be used with proxies like Nginx, ngrok, and Cloudflare Tunnel.
- Cross-origin access is allowed from `127.0.0.1` and `0.0.0.0` by default, and additional origins can be configured with `OLLAMA_ORIGINS`.
- Model storage locations are: macOS (`~/.ollama/models`), Linux (`/usr/share/ollama/.ollama/models`), and Windows (`C:\Users\%username%\.ollama`).

## Sources

- [[raw/Ollama FAQ.md|Original source]]
- Publisher: Ollama
- [Original publication](https://github.com/ollama/ollama/blob/main/docs/faq.mdx)

## Related notes

- [[Context Window Memory]] — Context length is one of the settings that controls memory use.
- [[Embeddings for Retrieval]] — A local runtime can also serve embedding models for retrieval.
