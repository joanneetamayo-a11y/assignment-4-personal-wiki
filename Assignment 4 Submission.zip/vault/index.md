# Personal Wiki

A small, source-traceable knowledge base. Generated notes require review against their originals.

## Local AI

- [[Local Runtime Settings]] — Context settings, GPU placement, and local-only operation.
- [[Context Window Memory]] — How the context window affects memory requirements.

## Retrieval

- [[Embeddings for Retrieval]] — Vectors, similarity search, and the retrieval stage of RAG.
