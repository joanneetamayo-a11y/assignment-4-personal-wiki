---
source_id: ollama-context
source_sha256: 8414ca2ad9c67fbd9bd1497bf352fb60993b2b5b69531118f456f9b31af87aa7
review_status: reviewed
---

# Context Window Memory

Context length is the maximum number of tokens a model has access to in memory, and setting a larger context length increases memory requirements.

## Details

- Context length is the maximum number of tokens the model has access to in memory.
- Ollama defaults for context length based on VRAM: 4k for < 24 GiB VRAM, 32k for 24-48 GiB VRAM, and 256k for >= 48 GiB VRAM.
- The source recommends at least 64,000 tokens for large-context tasks such as web search, agents, and coding tools. This wiki uses shorter selected passages and does not adopt that recommendation.
- Setting a larger context length increases the amount of memory required to run a model.
- Cloud models are set to their maximum context length by default.
- Context length can be set in the Ollama app settings or via the CLI using the environment variable: OLLAMA_CONTEXT_LENGTH=64000 ollama serve.
- The source recommends avoiding CPU offloading and using a large context when resources permit. For this small wiki, a 4,096-token context is a project choice to limit memory use, rather than a claim that every task needs the maximum window.
- The context length can be verified using `ollama ps`.

## Sources

- [[raw/Ollama Context Length.md|Original source]]
- Publisher: Ollama
- [Original publication](https://github.com/ollama/ollama/blob/main/docs/context-length.mdx)

## Related notes

- [[Local Runtime Settings]] — Runtime configuration determines the allocated context.
- [[Embeddings for Retrieval]] — Retrieving selected passages helps keep the generation context focused.
