---
source_id: ollama-faq
source_sha256: 7fc6dd6825f927e7e9e41f4b0d3e58b979d3c03cb29783f697fdc79a1c07a4d1
review_status: reviewed
---

# Local Runtime Settings

Information regarding upgrading Ollama, managing context window size, GPU detection, server configuration, proxy usage, data privacy, and network exposure.

## Details

- Ollama on macOS and Windows automatically downloads updates; on Linux, re-run the install script to update.
- This FAQ describes a default context window of 4096 tokens (the separate context-length source gives VRAM-dependent defaults), which can be overridden by the `OLLAMA_CONTEXT_LENGTH` environment variable or via `/set parameter` or API calls.
- GPU usage can be checked with `ollama ps`; the `Processor` column indicates if a model is loaded onto the GPU (e.g., `100% GPU`).
- Ollama server configuration uses environment variables, with specific instructions for macOS (`launchctl`), Linux (`systemd`), and Windows.
- Using a proxy requires setting the `HTTPS_PROXY` environment variable, and `HTTP_PROXY` should be avoided as Ollama only uses HTTPS for model pulls.
- Ollama can be run behind a proxy in Docker by setting `HTTPS_PROXY` in the container start command or configuring the Docker daemon.
- The FAQ says local prompts and data are not sent to Ollama. Its separate statements about processing cloud requests and collecting account information concern the hosted service; they should not be read as local-runtime logging guarantees.
- Ollama cloud features can be disabled by setting `disable_ollama_cloud` in `~/.ollama/server.json` or setting the `OLLAMA_NO_CLOUD` environment variable.
- Ollama can be exposed on a network by changing the bind address using the `OLLAMA_HOST` environment variable.
- Ollama can be used with proxies like Nginx, ngrok, and Cloudflare Tunnel.
- Cross-origin access is allowed from `127.0.0.1` and `0.0.0.0` by default, and additional origins can be configured with `OLLAMA_ORIGINS`.
- Model storage locations are: macOS (`~/.ollama/models`), Linux (`/usr/share/ollama/.ollama/models`), and Windows (`C:\Users\%username%\.ollama`).

## Sources

- [[raw/Ollama FAQ.md|Original source]] — context: lines 23–49; GPU: 51–75; local/cloud distinction: 159–181. Only the first 8,000 source characters were summarized; retrieval indexes the full original.
- Publisher: Ollama
- [Original publication](https://github.com/ollama/ollama/blob/main/docs/faq.mdx)

## Related notes

- [[Context Window Memory]] — Context length is one of the settings that controls memory use.
- [[Embeddings for Retrieval]] — A local runtime can also serve embedding models for retrieval.
