import unittest
from unittest.mock import patch
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import wiki
class HarnessTests(unittest.TestCase):
 def test_passages_preserve_original(self):
  text='first line\n'+('a line of original evidence\n'*150)
  chunks=list(wiki.passages(text))
  self.assertEqual(''.join(p[2] for p in chunks),text)
  for start,end,passage in chunks:self.assertEqual(''.join(text.splitlines(keepends=True)[start-1:end]),passage)
 def test_search_matches_source_slices(self):
  for hit in wiki.search('embeddings cosine similarity'):
   lines=(wiki.ROOT/hit['path']).read_text().splitlines(keepends=True)
   self.assertEqual(''.join(lines[hit['start']-1:hit['end']]),hit['passage'])
 def test_ask_never_loads_persona_or_chat(self):
  hits=[{'label':'S1','path':'test.md','start':1,'end':1,'passage':'Documented fact.'}]
  captured=[]
  def generate(messages):captured.extend(messages);return 'Documented fact [S1].',{}
  with patch.object(wiki,'search',return_value=hits),patch.object(wiki,'generate',side_effect=generate),patch.object(wiki,'save'):
   wiki.ask('What is documented?')
  self.assertEqual([x['role'] for x in captured],['system','user'])
  self.assertEqual(captured[0]['content'],wiki.instructions('research'))
  self.assertNotIn('Wren',str(captured))
 def test_unknown_citation_withheld(self):
  hits=[{'label':'S1','path':'test.md','start':1,'end':1,'passage':'Fact.'}]
  with patch.object(wiki,'search',return_value=hits),patch.object(wiki,'generate',return_value=('Invented [S99].',{})),patch.object(wiki,'save') as save:
   wiki.ask('Question')
   self.assertEqual(save.call_args.args[1]['answer'],wiki.INSUFFICIENT)
   self.assertEqual(save.call_args.args[1]['raw_model_answer'],'Invented [S99].')
 def test_no_hits_skips_model(self):
  with patch.object(wiki,'search',return_value=[]),patch.object(wiki,'generate') as generate,patch.object(wiki,'save'):
   wiki.ask('Nothing available');generate.assert_not_called()
 def test_casual_chat_skips_retrieval_and_uses_history(self):
  captured=[]
  def generate(messages):captured.append(messages);return 'Short draft.',{}
  with patch('builtins.input',side_effect=['Draft an invitation','make that shorter','/exit']),patch.object(wiki,'generate',side_effect=generate),patch.object(wiki,'search') as search,patch.object(wiki,'save'):
   wiki.chat();search.assert_not_called()
  self.assertEqual(captured[1][1]['content'],'Draft an invitation')
  self.assertEqual(captured[1][2]['content'],'Short draft.')
if __name__=='__main__':unittest.main()
